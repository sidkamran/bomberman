const bombs=[]
let Score=0;
let canPlay=true

function updateScore(){
    const gamePoints=document.getElementById("gamePoints")
    gamePoints.innerHTML="Your score is:"+Score
}
function grid(){
    const mainDiv=document.getElementById("app");
    for(let i=0;i<9;i++){
        const row=document.createElement("div");
        for(let j=0;j<9;j++){
            const index=i*9+j;
            const column=document.createElement("div");
            column.style.display="inline-block"
            column.style.height="50px"
            column.style.width="50px"
            column.style.border="1px solid black"
           // column.style.textAlign="center";
            column.style.verticalAlign="middle"
            column.setAttribute("index",index)
            column.addEventListener("click",function(){
                if(canPlay){
                if(bombs.includes(index)){
                    column.innerHTML=""
                  
                    column.style.background="red"
                    canPlay=false
                }
                else{
                    column.style.background="green";
                    Score++;
                    updateScore();
                }}
            })
            row.appendChild(column)
        }
        mainDiv.appendChild(row)

    }}
    function generateBomb(){
        while(bombs.length<11){
        const randomNumber=Math.floor(Math.random()*100);
            if(randomNumber<81 && !bombs.includes(randomNumber)){
            bombs.push(randomNumber);
            }
    }
    }

grid()
generateBomb()
console.log(bombs)